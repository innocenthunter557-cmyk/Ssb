import { z } from 'zod';
import sanitizeHtml from 'sanitize-html';

// ============================================================================
// Email
// ============================================================================
const MAX_EMAIL_LENGTH = 254; // RFC 5321 practical limit

export const emailSchema = z
  .string()
  .trim()
  .min(3, 'Invalid email')
  .max(MAX_EMAIL_LENGTH, 'Invalid email')
  .email('Invalid email')
  .refine((email) => {
    const [, domain] = email.split('@');
    if (!domain) return false;
    const labels = domain.split('.');
    if (labels.length < 2) return false;
    // Each DNS label: alphanumeric, may contain internal hyphens, no leading/trailing hyphen.
    return labels.every((label) => /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/.test(label));
  }, 'Invalid email')
  .transform((email) => email.toLowerCase());

// ============================================================================
// Password
// ============================================================================
const MIN_PASSWORD_LENGTH = 8;
// Upper bound is a DoS guard: without it, an attacker can send a multi-MB string
// and force the server to run an expensive Argon2id/bcrypt hash on it.
const MAX_PASSWORD_LENGTH = 72;

export const passwordSchema = z
  .string()
  .min(MIN_PASSWORD_LENGTH, `Password must be at least ${MIN_PASSWORD_LENGTH} characters`)
  .max(MAX_PASSWORD_LENGTH, `Password must be at most ${MAX_PASSWORD_LENGTH} characters`)
  .refine((pw) => /[A-Z]/.test(pw), 'Password must include an uppercase letter')
  .refine((pw) => /[a-z]/.test(pw), 'Password must include a lowercase letter')
  .refine((pw) => /[0-9]/.test(pw), 'Password must include a number')
  .refine((pw) => /[^A-Za-z0-9]/.test(pw), 'Password must include a special character');

// Login re-uses the length bound (DoS guard) but not the complexity rules —
// an existing password shouldn't be rejected at login just because today's
// policy is stricter than when the account was created.
export const loginPasswordSchema = z.string().min(1).max(MAX_PASSWORD_LENGTH);

// ============================================================================
// Username
// ============================================================================
const MAX_USERNAME_LENGTH = 30;

export const usernameSchema = z
  .string()
  .trim()
  .min(3, 'Username must be at least 3 characters')
  .max(MAX_USERNAME_LENGTH, `Username must be at most ${MAX_USERNAME_LENGTH} characters`)
  .regex(/^[a-zA-Z0-9_-]+$/, 'Username may only contain letters, numbers, underscores, and hyphens');

// ============================================================================
// Free text (bio, display name) — strip ALL markup, these render as plain text
// ============================================================================
const MAX_DISPLAY_NAME_LENGTH = 60;
const MAX_BIO_LENGTH = 500;

export function sanitizeFreeText(input: string): string {
  return sanitizeHtml(input, {
    allowedTags: [],
    allowedAttributes: {},
    disallowedTagsMode: 'discard',
  }).trim();
}

export const displayNameSchema = z
  .string()
  .max(MAX_DISPLAY_NAME_LENGTH)
  .transform(sanitizeFreeText)
  .refine((v) => v.length > 0, 'Display name cannot be empty');

export const bioSchema = z.string().max(MAX_BIO_LENGTH).transform(sanitizeFreeText).optional();

// ============================================================================
// Request schemas (one per endpoint)
// ============================================================================
export const signupSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  username: usernameSchema,
});

export const loginSchema = z.object({
  email: emailSchema,
  password: loginPasswordSchema,
});

export const passwordResetRequestSchema = z.object({
  email: emailSchema,
});

export const passwordResetConfirmSchema = z.object({
  token: z.string().min(20).max(500),
  newPassword: passwordSchema,
});

export const profileUpdateSchema = z.object({
  displayName: displayNameSchema.optional(),
  bio: bioSchema,
});
