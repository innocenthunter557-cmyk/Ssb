import { Redis } from '@upstash/redis';
import { Ratelimit } from '@upstash/ratelimit';

// Requires UPSTASH_REDIS_REST_URL and UPSTASH_REDIS_REST_TOKEN in your environment.
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
});

// 10 requests per IP per 60s window. Each call site passes its own prefix
// (e.g. `signup:${ip}` vs `reset-request:${ip}`) so limits don't bleed
// across endpoints.
//
// NOTE: account lockout, progressive delay, and CAPTCHA-threshold logic that
// used to live in this file were removed along with the custom /login route
// -- Clerk now owns login's abuse protection. If you later add another
// custom credential-checking endpoint, ask to have that logic regenerated
// rather than rebuilding it from scratch.
export const ipRateLimiter = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(10, '60 s'),
  prefix: 'ratelimit:ip',
});
