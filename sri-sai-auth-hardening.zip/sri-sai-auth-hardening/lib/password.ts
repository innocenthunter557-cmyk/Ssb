import argon2 from 'argon2';

// OWASP baseline for Argon2id. Benchmark on your actual production hardware and
// adjust memoryCost/timeCost to land around 250-400ms — these numbers are a
// reasonable starting point, not a guarantee for every environment.
const ARGON2_OPTIONS: argon2.Options = {
  type: argon2.argon2id,
  memoryCost: 19456, // ~19 MB
  timeCost: 2,
  parallelism: 1,
};

export async function hashPassword(plaintext: string): Promise<string> {
  // argon2.hash generates a fresh, cryptographically random salt internally.
  // Never pass a custom salt — that's a common source of subtle bugs.
  return argon2.hash(plaintext, ARGON2_OPTIONS);
}

/** Constant-time verification via the library's built-in comparison.
 *  Never compare hashes with === or == — argon2.verify does this safely. */
export async function verifyPassword(hash: string, plaintext: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, plaintext);
  } catch {
    // Malformed/corrupted hash in the DB — treat as a failed verification, not a crash.
    return false;
  }
}

/** True for legacy bcrypt ($2a$/$2b$/$2y$) or MD5/SHA1 hashes that predate a
 *  migration to Argon2id.
 *
 *  REMOVED (was here): the transparent rehash-on-login flow that used this
 *  lived entirely in app/api/auth/login/route.ts, which no longer exists —
 *  Clerk now owns login. If you're migrating existing users' legacy hashes
 *  into Clerk, that's a different problem (Clerk generally can't import raw
 *  password hashes across providers) — see MIGRATION.md's note on a
 *  one-time forced password reset during cutover instead. */

// Computed once per server process (not per request) and reused. Used to run a
// REAL Argon2id verification, at the same cost as a genuine check, when an
// account doesn't exist -- so response timing can't reveal account existence.
let cachedDummyHash: string | null = null;
export async function getDummyHash(): Promise<string> {
  if (!cachedDummyHash) {
    cachedDummyHash = await argon2.hash('dummy-timing-safety-password', ARGON2_OPTIONS);
  }
  return cachedDummyHash;
}
