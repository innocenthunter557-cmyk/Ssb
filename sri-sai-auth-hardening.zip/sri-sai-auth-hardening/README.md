# Sri Sai Boutique — Auth Hardening Scaffold

A from-scratch Next.js (App Router) + TypeScript implementation of the 5-point
auth security spec: server-side validation, rate limiting/lockout, Argon2id
hashing, anti-enumeration generic errors, and a managed-provider migration
path.

**Context:** no existing backend/auth code was found in this project to
harden — see MIGRATION.md and the chat for how this scaffold came to be.
Everything here is new, unreviewed-by-you code. Read it before deploying it.

## Structure

```
app/api/auth/signup/route.ts             Requirement 1, 3
app/api/auth/reset-password/request/     Requirement 4 (anti-enumeration)
app/api/auth/reset-password/confirm/     Requirement 3
app/api/profile/route.ts                 Requirement 1 (sanitization)
middleware.ts                            Route protection (CVE-2026-41248-safe pattern)
lib/validation.ts                        Zod schemas + sanitization
lib/password.ts                          Argon2id hashing/verify (login-only rehash logic removed)
lib/rateLimit.ts                         Upstash IP rate limit (lockout logic removed)
MIGRATION.md                             Requirement 5 -- login is now Clerk-hosted, see status there
```

**Login has no custom route or page in this project.** Clerk's hosted
sign-in owns that flow entirely — see MIGRATION.md for what that changed.

## Before you run this

1. `npm install` — this has NOT been run/built in a live environment; there
   was no network access available to install packages or verify the build
   compiles. Fix any version mismatches `npm install` surfaces.
2. Copy `.env.example` to `.env` and fill in real credentials (Upstash +
   Clerk — both required now, not optional).
3. Every `// TODO(you)` and commented-out `db.*` call needs wiring to your
   actual database/ORM — none of this assumes a specific one.
4. Benchmark `lib/password.ts`'s Argon2id cost parameters on your actual
   production hardware; the defaults target ~250-400ms but that varies by
   environment.
5. Follow MIGRATION.md's remaining steps to finish wiring Clerk into your
   actual `layout.tsx` (which this scaffold still doesn't have) — the
   `<ClerkProvider>` wrap and the sign-in/sign-up UI itself aren't done yet,
   only the backend side (middleware + the routes that remain custom).
