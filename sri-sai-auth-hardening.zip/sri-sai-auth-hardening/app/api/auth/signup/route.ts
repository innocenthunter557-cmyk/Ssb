import { NextRequest, NextResponse } from 'next/server';
import { signupSchema } from '@/lib/validation';
import { hashPassword } from '@/lib/password';
import { ipRateLimiter } from '@/lib/rateLimit';
// TODO(you): wire these to your actual database and email provider.
// import { db } from '@/lib/db';
// A verification email needs its own send function — lib/email.ts was
// removed along with the login route (it only ever held the lockout
// notifier); build this fresh rather than assuming a file that isn't there.
// async function sendVerificationEmail(email: string) { ... }

const GENERIC_RESPONSE = { message: 'Check your inbox to complete signup.' };

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown';

  const { success } = await ipRateLimiter.limit(`signup:${ip}`);
  if (!success) {
    return NextResponse.json({ message: 'Too many attempts. Try again later.' }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = signupSchema.safeParse(body);
  if (!parsed.success) {
    // Generic 400 — never echo back which field failed or its value.
    return NextResponse.json({ message: 'Invalid signup request.' }, { status: 400 });
  }
  const { email, password, username } = parsed.data;

  // const existing = await db.user.findUnique({ where: { email } });
  const existing = null as null | { id: string };

  if (existing) {
    // Don't reveal that the email is already registered. Notify the real
    // inbox instead of the HTTP response, and return the same generic
    // message either way — a script probing emails can't tell them apart.
    // await sendAccountExistsEmail(email);
    return NextResponse.json(GENERIC_RESPONSE, { status: 200 });
  }

  const passwordHash = await hashPassword(password);

  // await db.user.create({
  //   data: { email, username, passwordHash, emailVerified: false },
  // });
  // await sendVerificationEmail(email);

  return NextResponse.json(GENERIC_RESPONSE, { status: 200 });
}
