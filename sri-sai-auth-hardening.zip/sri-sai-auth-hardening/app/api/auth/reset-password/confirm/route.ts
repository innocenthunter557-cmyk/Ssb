import { NextRequest, NextResponse } from 'next/server';
import { passwordResetConfirmSchema } from '@/lib/validation';
import { hashPassword } from '@/lib/password';
import { ipRateLimiter } from '@/lib/rateLimit';
// TODO(you): wire to your actual database.
// import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown';
  const { success } = await ipRateLimiter.limit(`reset-confirm:${ip}`);
  if (!success) {
    return NextResponse.json({ message: 'Too many attempts. Try again later.' }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = passwordResetConfirmSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: 'Invalid or expired reset link.' }, { status: 400 });
  }
  const { token, newPassword } = parsed.data;

  // const record = await db.passwordResetToken.findUnique({ where: { token } });
  // if (!record || record.expiresAt < new Date()) {
  //   return NextResponse.json({ message: 'Invalid or expired reset link.' }, { status: 400 });
  // }

  const passwordHash = await hashPassword(newPassword);

  // await db.user.update({ where: { id: record.userId }, data: { passwordHash } });
  // await db.passwordResetToken.delete({ where: { token } });

  // Note: unlike the request endpoint, it's fine to be specific here — by this
  // point the caller already possesses a token from their own inbox, so this
  // response isn't an enumeration vector the way the request endpoint is.
  return NextResponse.json({ message: 'Password updated.' }, { status: 200 });
}
