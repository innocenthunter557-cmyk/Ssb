import { NextRequest, NextResponse } from 'next/server';
import { passwordResetRequestSchema } from '@/lib/validation';
import { getDummyHash, verifyPassword } from '@/lib/password';
import { ipRateLimiter } from '@/lib/rateLimit';
// TODO(you): wire to your actual database + email provider.
// import { db } from '@/lib/db';
// A reset-link email needs its own send function — lib/email.ts was removed
// along with the login route (it only ever held the lockout notifier);
// build this fresh rather than assuming a file that isn't there.
// async function sendPasswordResetEmail(email: string, token: string) { ... }
// import crypto from 'crypto';

const GENERIC_MESSAGE = {
  message: "If that email is registered, you'll receive a password reset link.",
};

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown';
  const { success } = await ipRateLimiter.limit(`reset-request:${ip}`);
  if (!success) {
    return NextResponse.json({ message: 'Too many attempts. Try again later.' }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = passwordResetRequestSchema.safeParse(body);
  if (!parsed.success) {
    // Even a malformed request gets the generic message — the error itself
    // shouldn't be a distinguishable signal.
    return NextResponse.json(GENERIC_MESSAGE, { status: 200 });
  }
  const { email } = parsed.data;

  // const user = await db.user.findUnique({ where: { email } });
  const user = null as null | { id: string; email: string };

  if (user) {
    // const token = crypto.randomBytes(32).toString('hex');
    // await db.passwordResetToken.create({
    //   data: { userId: user.id, token, expiresAt: new Date(Date.now() + 30 * 60 * 1000) },
    // });
    // await sendPasswordResetEmail(user.email, token);
  } else {
    // No real user — still do an equivalent amount of work so response
    // timing doesn't reveal whether the email was registered.
    await verifyPassword(await getDummyHash(), 'irrelevant-value');
  }

  return NextResponse.json(GENERIC_MESSAGE, { status: 200 });
}
