import { NextRequest, NextResponse } from 'next/server';
import { profileUpdateSchema } from '@/lib/validation';
// If you migrate to Clerk (see MIGRATION.md), swap the two lines below for:
// import { auth } from '@clerk/nextjs/server';

// Deliberately check auth HERE, not just in middleware.ts. CVE-2026-41248
// showed that a middleware route-protection bypass is possible under some
// patterns — routes that verify the session themselves stay safe even if
// middleware gating is ever bypassed again in some future issue. Don't treat
// middleware as your only line of defense for anything sensitive.
// TODO(you): wire to your actual database.
// import { db } from '@/lib/db';

export async function PATCH(req: NextRequest) {
  // const { userId } = auth();
  // if (!userId) {
  //   return NextResponse.json({ message: 'Unauthorized.' }, { status: 401 });
  // }
  const userId = 'TODO-wire-up-real-session'; // replace with your real session/user lookup

  const body = await req.json().catch(() => null);
  const parsed = profileUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: 'Invalid profile update.' }, { status: 400 });
  }

  // displayName/bio are already HTML-stripped by the schema's sanitize step —
  // never trust that the client did this, even if your form already does.
  const { displayName, bio } = parsed.data;

  // await db.user.update({ where: { id: userId }, data: { displayName, bio } });

  return NextResponse.json({ message: 'Profile updated.' }, { status: 200 });
}
