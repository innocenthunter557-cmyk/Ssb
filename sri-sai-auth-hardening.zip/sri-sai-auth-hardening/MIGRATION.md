# Migrating to a Managed Auth Provider (Requirement 5)

## Current status

**Login is done — it's Clerk's, not this codebase's.** `app/api/auth/login/route.ts`
was removed at your request; there's no custom login route or page anymore.
Signup and password reset are still this project's own custom code (nobody's
asked to move those yet). This is a real hybrid state, not a temporary one —
see the sections below for what that means for requirements 2 and 4
specifically.

This project now ships:

1. **Custom signup + password-reset** (`app/api/auth/signup`,
   `app/api/auth/reset-password/*`, `lib/*`) — still fully implements
   requirements 1, 3, and 4 for those two flows.
2. **Clerk for login** — requirement 5, for login specifically, is done, not
   just recommended. The remaining setup steps below (`<ClerkProvider>`,
   actual sign-in UI) still need doing since this scaffold never had your
   real `layout.tsx` to edit.

## ⚠️ One nuance worth being explicit about: requirements 2 and 4, for login

Before the removal, `app/api/auth/login/route.ts` implemented this spec's
*exact* wording — "Incorrect email or password." verbatim, 10 req/min, 5-fail
lockout, 15-minute duration. Clerk now owns login instead, and Clerk has its
own abuse-protection and error-message behavior — reasonable and
well-engineered, but **not verified here to match those exact numbers or that
exact wording**. If matching the spec's literal thresholds for login
specifically actually matters (e.g. a compliance requirement, not just good
practice), that's worth checking against Clerk's current docs rather than
assuming it lines up. Signup and password-reset still use this project's own
code, so their numbers/wording are exactly as specified.

## Why recommend Clerk specifically

Given this is a Next.js App Router project, Clerk has the most direct
integration of the four options in the original spec (Supabase Auth, Firebase
Auth, Auth0 all work too, but need more custom wiring for App Router route
handlers and middleware). Clerk gets you, with no custom code:

- Password hashing, rate limiting, and account lockout — handled by Clerk's
  infrastructure, not yours to maintain.
- MFA as an opt-in per-user setting (toggle in the Clerk dashboard, no code).
- Google + GitHub OAuth (toggle in the dashboard, no code).
- Session management and JWT verification.

## ⚠️ Before you install anything: CVE-2026-41248

`@clerk/nextjs` had a critical (CVSS 9.1) middleware route-protection bypass,
disclosed April 2026. The vulnerable pattern was an **allow-list** — matching
specific protected routes and calling `auth.protect()` only on a match.
Crafted requests could evade the matcher and reach handlers completely
unauthenticated.

- Affected: v5.0.0–5.7.5, v6.0.0–6.39.1, v7.0.0–7.2.0
- Fixed: 5.7.6, 6.39.2, 7.2.1 (this project's `package.json` pins `^7.5.0`)
- The fix is a **pattern change**, not just a version bump — Clerk's own
  guidance is to use default-deny (protect everything, explicitly allow-list
  what's public), which is what `middleware.ts` in this project already does.

Run `npm ls @clerk/nextjs` and `npm why @clerk/shared` after installing to
confirm you're on patched versions — `@clerk/shared` is a transitive
dependency with its own separate affected range.

## What's already replaced vs. what's still custom

| This project's file | Status |
|---|---|
| `app/api/auth/login/route.ts` | **Gone.** Replaced by Clerk's `<SignIn />` component / hosted sign-in page |
| `lib/rateLimit.ts` (lockout/captcha/delay portion) | **Gone** with it — file now only keeps the IP limiter signup/reset still use |
| `lib/password.ts` (`needsRehash`, login-only) | **Gone** — was only for transparent rehash-on-login |
| `app/api/auth/signup/route.ts` | Still custom — not yet migrated |
| `app/api/auth/reset-password/*` | Still custom — not yet migrated |
| `lib/password.ts` (`hashPassword`/`verifyPassword`/`getDummyHash`) | Still custom — signup/reset-password depend on these |

## What still matters after migrating

Clerk manages **identity**, not your **application data**. Requirement 1's
validation/sanitization still applies to anything that isn't Clerk's business:

- `app/api/profile/route.ts` — your own `displayName`/`bio` fields still need
  `lib/validation.ts`'s sanitization. Clerk doesn't know these fields exist.
- Your own database should store only `clerkUserId`, plan, and preferences —
  never passwords, session tokens, or refresh tokens. Clerk holds those.

## Remaining steps

1. `npm install @clerk/nextjs@latest` (confirms ≥7.2.1 automatically).
2. Add `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` / `CLERK_SECRET_KEY` from the Clerk
   dashboard to `.env` — this scaffold's `.env.example` already expects them.
3. Wrap your root layout in `<ClerkProvider>` (see Clerk's Next.js quickstart
   for the current exact snippet — their App Router setup has changed across
   major versions, so use their live docs rather than a pasted snippet here).
   This scaffold doesn't have your real `layout.tsx`, so this step is still
   entirely undone.
4. `middleware.ts` is already written for this (default-deny pattern,
   CVE-safe) — nothing to change there.
5. In the Clerk dashboard: enable Google + GitHub OAuth, enable MFA as an
   optional user setting.
6. If/when you're ready to move signup and password-reset too: delete
   `app/api/auth/signup`, `app/api/auth/reset-password/*`, and the rest of
   `lib/password.ts` and `lib/rateLimit.ts` — keep `lib/validation.ts`'s
   sanitization for `app/api/profile/route.ts`, since Clerk doesn't manage
   that field.
7. Migrate existing users: Clerk supports bulk user import; existing password
   hashes generally can't be imported (most providers require the user to
   reset their password once, since hash formats aren't portable across
   providers) — plan for a one-time "reset your password" email to your
   existing user base during cutover.
