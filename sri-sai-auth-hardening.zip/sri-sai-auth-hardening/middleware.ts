// This assumes Clerk (see MIGRATION.md for why). If you're not using Clerk yet,
// see the commented generic-JWT version at the bottom of this file.
//
// SECURITY NOTE — CVE-2026-41248 (CVSS 9.1, disclosed April 2026):
// @clerk/nextjs had a critical middleware bypass in the ALLOW-LIST pattern
// (matching specific protected routes, calling auth.protect() only on a
// match). Crafted requests could evade the matcher and reach handlers
// completely unauthenticated. Fixed in 5.7.6 / 6.39.2 / 7.2.1 — but the fix
// is a PATTERN change, not just a version bump: Clerk's own guidance is to
// use a default-deny pattern (protect everything, explicitly allow-list the
// public routes) rather than the inverse. This file already uses that safe
// pattern below. Run `npm ls @clerk/nextjs` (and `npm why @clerk/shared`,
// since it's a transitive dependency with its own affected range) to confirm
// you're on a patched version before relying on this alone.
//
// Defense in depth: app/api/profile/route.ts also checks auth() itself
// rather than trusting middleware alone — per Clerk's own advisory, routes
// that check auth() directly were never exploitable even during the bypass
// window, since auth() itself always reported the real session state
// correctly. Don't rely on middleware as your only gate.

import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server';

// Default-deny: list what's PUBLIC, protect everything else by default.
// (The vulnerable pattern did the inverse — listed what's protected — which
// is exactly what CVE-2026-41248 exploited when the matcher missed a route.)
const isPublicRoute = createRouteMatcher([
  '/',
  '/sign-in(.*)',
  '/sign-up(.*)',
  '/api/auth/(.*)', // the routes built in this project — they handle their own rules
]);

export default clerkMiddleware(async (auth, req) => {
  if (!isPublicRoute(req)) {
    await auth.protect();
  }
});

export const config = {
  matcher: ['/((?!_next|.*\\..*).*)', '/(api|trpc)(.*)'],
};

/* ---- Generic fallback if you are NOT using Clerk ----
import { NextRequest, NextResponse } from 'next/server';

const PUBLIC_PATHS = ['/', '/login', '/signup', '/api/auth'];

export function middleware(req: NextRequest) {
  const isPublic = PUBLIC_PATHS.some((p) => req.nextUrl.pathname.startsWith(p));
  if (isPublic) return NextResponse.next();

  const token = req.cookies.get('session')?.value;
  if (!token) {
    return NextResponse.redirect(new URL('/login', req.url));
  }
  // TODO(you): verify the token's signature/expiry here (e.g. jose's jwtVerify) —
  // don't just check that a cookie is present.
  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next|.*\\..*).*)', '/(api|trpc)(.*)'],
};
---- */
